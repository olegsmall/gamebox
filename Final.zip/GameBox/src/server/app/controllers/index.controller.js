



exports.index = async function(req, res) {

  res.render('index', {
    content: '<h2>Text</h2>'
  });
};
